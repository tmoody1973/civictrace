# CivicTrace Python Backend

## Purpose

The backend is the CivicTrace control plane and intelligence plane. It owns source-event intake, raw artifact preservation, deterministic validation, bounded ADK invocations, case/ledger persistence, approval checks, and internal asynchronous worker execution. It never lets a model directly write case state or perform an external side effect.

## Intended Runtime

| Service | Deployment | Responsibility |
|---|---|---|
| `civictrace-api` | Authenticated Cloud Run service | Health, cases, evidence inspection, corrections, review and approval requests. |
| `civictrace-worker` | Internal IAM-authenticated Cloud Run service | Cloud Task work: source retrieval, artifact vault, ADK runs, validation, case update, packet rendering. |

## Initial Dependencies

Create `pyproject.toml` with a modern supported Python version and the smallest dependency set necessary for the first replay loop. The expected categories are FastAPI/Uvicorn, Pydantic, Google ADK, Google Cloud Storage/Firestore/PubSub/Tasks/BigQuery clients, HTTP client, structured logging, `pytest`, `pytest-asyncio`, and type/lint tools. Add PDF/media libraries only once a reviewed fixture demands them.

## Local Setup Sequence

1. Copy the root `.env.example` to `.env` and fill only non-secret local values.
2. Authenticate to a dedicated development Google Cloud project through supported local credentials; do not place service-account JSON in the repository.
3. Create the reviewed City replay corpus manifest from `docs/sources/corpus-manifest.example.yaml`.
4. Implement/test domain schemas and deterministic validators first.
5. Add an in-memory/fake repository implementation for local tests before a Firestore implementation.
6. Add the City source adapter and raw artifact vault; use a local fixture/replay mode before live polling.
7. Add one Document Evidence ADK agent and a fixture-based evaluation before adding the full agent team.

## Required Commands Once Tooling Exists

```bash
# run lint/type/tests from backend/
uv run ruff check .
uv run mypy app
uv run pytest tests/unit tests/evaluations

# run the local API after app/main.py exists
uv run uvicorn app.main:app --reload --port 8080

# replay only reviewed public fixture corpus
uv run python scripts/replay_corpus.py --manifest ../docs/sources/corpus-manifest.yaml
```

Do not invent test data representing public records. Use reviewed public fixture files or synthetic non-sensitive failure fixtures only.
